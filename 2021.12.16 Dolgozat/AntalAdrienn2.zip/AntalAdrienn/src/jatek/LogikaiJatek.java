package jatek;

public class LogikaiJatek extends Jatek {

    private Babu[][] tabla;
    private int[] sorrend;
    private int babuDb;

    public LogikaiJatek(int babuDb) throws IllegalArgumentException {
        if (babuDb >= 3 && babuDb <= 15) {
            this.babuDb = babuDb;
        } else {
            throw new IllegalArgumentException("Helytelen babuDB!");
        }
        this.tabla = tablaFeltolt();
        this.sorrend = sorrendBeallit();
    }

    public LogikaiJatek() {
        this(3);
    }

    public int[][] veletlenIndexParosok(){    
            int[][] veletlenIndexParosok = new int [babuDb][2];
            int i=0;
            boolean talalt=false;
            while(i<veletlenIndexParosok.length) {
            if(talalt && i>0){
                i--;
            }    
            int szamX=(int) (Math.random() * 4);
            int szamY=(int) (Math.random() * 5);            
            int j = 0;
            talalt = false;
            
            while (j < veletlenIndexParosok.length && !talalt) {
                if (veletlenIndexParosok[j][0] == szamX && veletlenIndexParosok[j][1]==szamY) {
                    talalt = true;
                }                
                j++;
            };           
            if (talalt==false) {
                veletlenIndexParosok[i][0] = szamX;
                veletlenIndexParosok[i][1]=szamY;              
            }            
            i++;            
            }
//            for (int k = 0; k < veletlenIndexParosok.length; k++) {
//            System.out.print(veletlenIndexParosok[k][0]+" ");
//            System.out.println(veletlenIndexParosok[k][1]);
//            }
//            System.out.println();
    return veletlenIndexParosok;
    }
   
    public Babu[][] tablaFeltolt() {  
        int[][] indexParosok = veletlenIndexParosok();
        boolean talalt = false;
        Babu[][] matrix = new Babu[4][5];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {                
                for (int k = 0; k < indexParosok.length; k++) {
                     talalt = (i==indexParosok[k][0] && j==indexParosok[k][1]);
                if(talalt)
                    matrix[i][j] = new Babu(eroBeallitas(), szinBeallitas());
                }
                
            }
        }

        return matrix;
    }

    public String tablatartalmaKiir() {
        
        String txt = "";
        for (int i = 0; i < tabla.length; i++) {
            for (int j = 0; j < tabla[i].length; j++) {
                if (tabla[i][j] != null){
                    txt += tabla[i][j].getSzin() + tabla[i][j].getEro() + " ";
                }
                else
                {
                    txt += "-- ";
                }
            }
            txt += "\n";
        }
        return txt;
    }

    public boolean van8FelettEro() {
        boolean van = false;
        for (int i = 0; i < tabla.length; i++) {
            for (int j = 0; j < tabla[i].length; j++) {
                if (tabla[i][j]!=null && tabla[i][j].getEro() > 8) {
                    van = true;
                }
            }
        }
        return van;
    }

    public String nyolcfeletti() {
        String nyolcfeletti = "";
        if (van8FelettEro()) {
            nyolcfeletti = "van";
        } else {
            nyolcfeletti = "nincs";
        }
        return nyolcfeletti;
    }

    @Override
    public void kezd() {
        System.out.println("Kezdés");

    }

    @Override
    public void ment() {
        System.out.println("Mentés");

    }

    @Override
    public void vege() {
        System.out.println("Vége!");

    }

    @Override
    public String toString() {

        return sorrendKiir() + tablatartalmaKiir() + "\n 8 feletti: " + nyolcfeletti()+"\n\n";
    }

    public String szinBeallitas() {
        String[] szinek = {"P", "F"};
        int randomIndex = (int) Math.round(Math.random());
        return szinek[randomIndex];
    }

    public int eroBeallitas() {
        int ero = (int) (Math.random() * 9) + 1;
        return ero;
    }

    public int[] sorrendBeallit() {
         int[] sorrendTomb = new int[10];
        int i = 0;
        boolean talalt=false;
        while (i < sorrendTomb.length) {
            if(talalt && i>0){
                i--;
            }
            int szam = (int) (Math.random() * 15) + 1;            
            int j = 0;
            talalt = false;
            while (j < sorrendTomb.length && !talalt) {
                if (sorrendTomb[j] == szam) {
                    talalt = true;
                }                
                j++;
            };           
            if (talalt==false) {
                sorrendTomb[i] = szam;                
            }
            i++;
            
        }
        return sorrendTomb;
    }

    public String sorrendKiir() {
        String txt = "";
        for (int i = 0; i < sorrend.length; i++) {
            txt += sorrend[i] + " ";
        }
        return txt + "\n";
    }

}
