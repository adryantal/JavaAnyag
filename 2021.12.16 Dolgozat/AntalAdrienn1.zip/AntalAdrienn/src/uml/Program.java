
package uml;


public class Program {
    
       public static void main(String[] args) {
           
           Jatek j1 = new LogikaiJatek(3);
           Jatek j2 = new LogikaiJatek(10);
       
    }
    
}
