package jatek;

public class LogikaiJatek extends Jatek {

    private Babu[][] tabla;
    private int[] sorrend;
    private int babuDb;

    public LogikaiJatek(int babuDb) throws IllegalArgumentException {
        if (babuDb >= 2 && babuDb <= 15) {
            this.babuDb = babuDb;
        } else {
            throw new IllegalArgumentException("Helytelen babuDB!");
        }
        this.tabla = new Babu[4][5];
        this.sorrend = new int[10];
    }

    public LogikaiJatek() {
        this(2);
    }

    public boolean van8FelettEro() {
        return true;
    }

    @Override
    public void kezd() {
        System.out.println("Kezdés");

    }

    @Override
    public void ment() {
        System.out.println("Mentés");

    }

    @Override
    public void vege() {
        System.out.println("Vége!");

    }

    @Override
    public String toString() {
        return "LogikaiJatek { Bábuk száma: " + babuDb + '}';
    }

}
