
package jatek;


public class Program {
    
       public static void main(String[] args) {
       
           
           
        try {  
            
           /*teszt*/
          // Jatek j1 = new LogikaiJatek(1); 
           
          Jatek j1 = new LogikaiJatek(3); 
          Jatek j2 = new LogikaiJatek(10);
           
           /*teszt*/
          //System.out.println(((LogikaiJatek)j1).toString());
           
           
        } catch (IllegalArgumentException e) { 
        
            System.out.println(e.toString());
        }    
        
       
         
         
    }
   
}
