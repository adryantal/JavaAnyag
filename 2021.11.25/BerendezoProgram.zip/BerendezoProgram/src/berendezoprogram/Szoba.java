package berendezoprogram;
public class Szoba {
    /* ADATTAGOK -rejtve a külvilág elől */
    private Asztal asztal;
    private Redony elsoRedony, hatsoRedony;

    /* TAGFÜGGVÉNYEK */
    /* GENERÁLT KÓD: ALT + INSERT */
    //cstr: minden adattagot inicializálnia kell
    public Szoba(Redony elso, Redony hatso, Asztal asztal) {
        this.asztal = asztal;
        this.elsoRedony = elso;
        this.hatsoRedony = hatso;
    }

    public Redony getElsoRedony() { return elsoRedony; }
    public Redony getHatsoRedony() { return hatsoRedony; }
    public Asztal getAsztal() { return asztal; }

    @Override
    public String toString() {
        return "Szoba{" 
                + "\n\tasztal=" + asztal 
                + "\n\telsoRedony=" + elsoRedony 
                + "\n\thatsoRedony=" + hatsoRedony 
                + "\n}";
    }
    
    /* SAJÁT */
    public void mindenRedonytLeenged(){
        elsoRedony.leenged(elsoRedony.getMag());
        hatsoRedony.leenged(hatsoRedony.getMag());
        
        /* ez valamilyen kódduplikálás, 
            ha módosítom a redőnyök tárolását, akkor 2 helyen kell
            átírni a kódot.
            A redőnyök nem egyform amagassak, de lehet
            egy nem szép megoldás:
            mindenRedonytLeenged(Integer.MAX_VALUE);
        */
        
    }
    
    public void mindenRedonytLeenged(int aktMag){
        elsoRedony.leenged(aktMag);
        hatsoRedony.leenged(aktMag);
    }
    
    public void mindenRedonytFelhuz(){
        elsoRedony.felhuz();
        hatsoRedony.felhuz();
    }
}
