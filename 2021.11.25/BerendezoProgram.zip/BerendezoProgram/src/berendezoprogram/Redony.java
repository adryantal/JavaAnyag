package berendezoprogram;
public class Redony {
    /* ADATTAGOK -rejtve a külvilág elől */
    private int szel, mag, aktMag;
    private boolean zart;
    
    /* TAGFÜGGVÉNYEK */
    /* GENERÁLT KÓD: ALT + INSERT */
    //cstr: minden adattagot inicializálnia kell
    public Redony(int szel, int mag) {
        this.szel = szel;
        this.mag = mag;
        aktMag = 0;
        zart = true;
    }

    //setter
    //public void setAktMag(int aktMag) { this.aktMag = aktMag; }
    public void leenged(int aktMag) {
        if(aktMag > mag){ aktMag = mag; }
        this.aktMag = aktMag; 
    }

    public void setZart(boolean zart) {
        this.zart = zart;
    }
    
    //getterek
    public int getSzel() { return szel; }
    public int getMag() { return mag; }
    public int getAktMag() { return aktMag; }    
    public boolean isZart() { return zart; }

    @Override
    public String toString() {
        return "Redony{" + "szel=" + szel + ", mag=" + mag + ", aktMag=" + aktMag + ", zart=" + zart + '}';
    }
    
    /* SAJÁT */
    //az info feladatát a generált toString látja el
    //public void info(){ /* adattagok kiírása */ }
    
    public void felhuz(){
        aktMag = 0;
    }
    
    public void rajzol(){
        
        vonal();
        for (int i = 0; i < aktMag; i++) {
            char jel = zart ? ' ' : '-';
            vonal('|', jel);
        }
        vonal();
    }

    private void vonal() {
        vonal('*','*');
    }

    private void vonal(char zaro, char jel) {
        System.out.print(zaro);
        for (int i = 0; i < szel; i++) {
            System.out.print(jel);
        }
        System.out.println(zaro);
    }
    
}
