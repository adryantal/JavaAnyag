package hengerprogram;
public class LyukasHenger extends TomorHenger{
    private double falvastagsag;

    public LyukasHenger(double r, double m, double falvastagsag) {
        this(r, m, 1, falvastagsag);
    }

    public LyukasHenger(double r, double m, double fajsuly, double falvastagsag) {
        super(r, m, fajsuly);
        this.falvastagsag = falvastagsag;
    }

    @Override
    public String toString() {
        String os = super.toString();
        return os + "\n\t\tLyukasHenger{" + "falvastagsag=" + falvastagsag + '}';
    }

     @Override
    public double terfogat() {
        Henger belso = new Henger(this.getR() - falvastagsag, this.getM());
        return super.terfogat() - belso.terfogat();
    }
    
}
