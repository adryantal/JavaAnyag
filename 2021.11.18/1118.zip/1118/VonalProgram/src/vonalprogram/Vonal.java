package vonalprogram;
public class Vonal {
    private int hossz;
    private int kezdX;
    private String tipus;
    private String szin;
    
    /* HF: megoldani vmelyik verzióval */
    public static final String SZAGGATOTT = "sz";
    public enum Tipusok{SZAGGATOTT};
    
    /* GENERÁLT KÓDOK: ALT+INSERT */
    public Vonal() {
        //hossz = 1;
        this(1);
    }
    
    public Vonal(int hossz) {
        //this.hossz = hossz;
        this(hossz, 0);
    }
    
    public Vonal(int hossz, int kezdX) {
        //this.hossz = hossz;
        //this.kezdX = kezdX;
        this(hossz, kezdX, "normál");
        //this(hossz, kezdX, "normál", "fekete");
    }

    public Vonal(int hossz, int kezdX, String tipus) {
        //this.hossz = hossz;
        //this.kezdX = kezdX;
        //this.tipus = tipus;
        this(hossz, kezdX, tipus, "lila");
    }

    public Vonal(int hossz, int kezdX, String tipus, String szin) {
        if(hossz < 1){ hossz = 1; }
        this.hossz = hossz;
        this.kezdX = kezdX;
        this.tipus = tipus;
        this.szin = szin;
    }
    
    public void info(){
        System.out.printf("Vonal{H:%d, X:%d, T:%s, Sz:%s}\n",hossz, kezdX, tipus, szin);
    }
    
    public void rajzol(){
        //adattagok alapján kirajzoljuk:
        
        eltolas();
        //char jel = tipusBeallitas();
        //String rajzSzin = szinBeallitas();
        //hosszBeallitas(rajzSzin, jel);
        hosszSzinTipusRajzol();
    }

    private void eltolas() {
        //eltolás
        for (int i = 0; i < kezdX; i++) {
            System.out.print(" ");
        }
    }
    
    private void hosszSzinTipusRajzol() {
        
        System.out.print(szinBeallitas());
        //hossz
        for (int i = 0; i < hossz; i++) {
            //System.out.print(rajzSzin);
            //System.out.print(jel);
            System.out.print(tipusBeallitas());
        }
        System.out.println(szinBeallitas(true));
    }

    private char tipusBeallitas() {
        //tipus
        char jel;
        switch(tipus){
            default: /* normál */
                jel = '_'; break;
            case "szaggatott":
                jel = '-'; break;
            case "pont":
                jel = '.'; break;
            case "dupla":
                jel = '='; break;
        }
        return jel;
    }

    private String szinBeallitas() {
        return szinBeallitas(false);
    }

    private String szinBeallitas(boolean kellReset) {
        //szín
        //piros: "\033[0;31m"
        //zöld:  "\033[0;32m";
        //reset: "\033[0m";
        String fekete = "\033[0;30m";
        String piros = "\033[0;31m";
        String zold = "\033[0;32m";
        String lila = "\033[0;35m";
        String cyan = "\033[0;36m";
        String reset = "\033[0m";
       
        String rajzSzin = reset;
        if(kellReset){
            return rajzSzin;
        }
        
        switch(szin){
            default:
                rajzSzin = lila; /*fekete;*/ break;
            case "piros":
                rajzSzin = piros; break;
            case "zöld":
                rajzSzin = zold; break;
        }
        
        return rajzSzin;
    }
    
}
