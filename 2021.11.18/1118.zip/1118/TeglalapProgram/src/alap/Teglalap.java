package alap;
/* itt csak a Teglalap -ra jellemző kód van */
public class Teglalap {
    /* Egységbezárjuk
     - a téglalpokra jellemző adattagokat
     - az addattagokon végezhető műveleteket
     
     Az adattagokat el is rejtjük a külvilág elöl
    */
}
