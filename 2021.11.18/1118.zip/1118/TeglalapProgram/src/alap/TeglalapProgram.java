package alap;
/* Itt van a program működési logikája */
public class TeglalapProgram {
    public static void main(String[] args) {
        // példányosítunk és hívjuk a publikus metódusokat
    }
    
}
