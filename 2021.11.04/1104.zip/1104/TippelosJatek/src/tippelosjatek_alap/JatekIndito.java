package tippelosjatek_alap;
public class JatekIndito {

    public static void main(String[] args) {
        Jatek jatek = new Jatek();
        jatek.start();
    }
    
}
