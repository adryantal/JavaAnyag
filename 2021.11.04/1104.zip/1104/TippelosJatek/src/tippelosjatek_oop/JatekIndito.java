package tippelosjatek_oop;

public class JatekIndito {

    public static void main(String[] args) {
        //Jatek jatek = new Jatek();
        //jatek.start();
        
        new Jatek().start();
    }
    
}
