package faidomokprogram;

import idomok.FaIdom;
import java.util.ArrayList;

public class FaIdomok {
    private ArrayList<FaIdom> idomok;

    public FaIdomok() {
        idomok = new ArrayList<>();
    }
    
    public void run(){
    
    }
    
    public double osszSuly(){
        return 0;
    }
    
    public double osszGombSuly(){
        return 0;
    }
    
    public FaIdom minV(){
        return null;
    }
    
    public FaIdom maxV(){
        return null;
    }
}
