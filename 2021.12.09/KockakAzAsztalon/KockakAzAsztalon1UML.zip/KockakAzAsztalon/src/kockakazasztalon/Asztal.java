package kockakazasztalon;
public class Asztal {
    private Kocka[] kockak;

    public Asztal() {
        kockak = new Kocka[2];
    }

    public Asztal(Kocka[] kockak) {
        this.kockak = kockak;
    }
    
    public Asztal(int kockaDb) {
        kockak = new Kocka[kockaDb];
    }
    
    public void belerug(){}
}
