package kockakazasztalon;

public class Kocka {
    private int oldalSzam, dobottErtek;

    public Kocka() {
    }
    
    public Kocka(int oldalSzam) {
        this.oldalSzam = oldalSzam;
    }

    public int dob(){
        return 0;
    }
    
    public int megnez(){
        return 0;
    }
}
