package kockakazasztalon;

public class Program {

    public static void main(String[] args) {
        Asztal asztal = new Asztal();
        //ha belerugok, akkor tobbet nem erem el a kockakat...
        
        
        Kocka[] kockak = {new Kocka(), new Kocka()};
        asztal = new Asztal(kockak);
        asztal.belerug();
        
        System.out.println("Kockák a talajon: ");
        System.out.println("k0: " + kockak[0].megnez());
        System.out.println("k1: " + kockak[1].megnez());
    }
    
}
