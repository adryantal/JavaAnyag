package kockakazasztalon;

public class Kocka {
    private int oldalSzam, dobottErtek;

    public Kocka() {
        this(6);
    }
    
    public Kocka(int oldalSzam) {
        this.oldalSzam = oldalSzam;
        this.dobottErtek = dob();
    }

    public int dob(){
        dobottErtek = (int)(Math.random()*oldalSzam)+1;
        return dobottErtek;
    }
    
    public int megnez(){
        return dobottErtek;
    }
}
