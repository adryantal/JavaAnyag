package kockakazasztalon;
public class Asztal {
    private Kocka[] kockak;

    public Asztal() {
        kockak = new Kocka[2];
        kockak[0] = new Kocka();
        kockak[1] = new Kocka();
    }

    public Asztal(int kockaDb) {
        //kockak = new Kocka[kockaDb];
        this(new Kocka[kockaDb]);
    }
    
    public Asztal(Kocka[] kockak) {
        this.kockak = kockak;
        
    }
    
    public void belerug(){
        kockak = new Kocka[0];
    }
}
